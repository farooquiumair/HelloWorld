/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.99889071304965, "KoPercent": 0.001109286950348316};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7085293073612282, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9961103253182461, 500, 1500, "S05_T02_Get user Blocked"], "isController": false}, {"data": [0.6872990353697749, 500, 1500, "S07_T06b_PAMRequest_Denied"], "isController": false}, {"data": [0.9300911854103343, 500, 1500, "S08_T03d_Request_To_Pay-20KB"], "isController": false}, {"data": [0.9527027027027027, 500, 1500, "S10_T03a_Request_To_Pay-1KB"], "isController": false}, {"data": [0.6, 500, 1500, "S10_T01_GetUserToken"], "isController": false}, {"data": [0.9510385756676558, 500, 1500, "S11_T03d_Request_To_Pay-20KB"], "isController": false}, {"data": [0.11863313990973566, 500, 1500, "S11_T04_NoteToBiller"], "isController": false}, {"data": [0.10642317380352645, 500, 1500, "S08_T04a_PayAll"], "isController": false}, {"data": [0.2917090539165819, 500, 1500, "S12_T04_Get_ListOfMessages_In_A_Thread"], "isController": false}, {"data": [0.9347389558232931, 500, 1500, "S10_T03c_Request_To_Pay-10KB"], "isController": false}, {"data": [0.9472049689440993, 500, 1500, "S11_T03b_Request_To_Pay-5KB"], "isController": false}, {"data": [0.634185303514377, 500, 1500, "S07_T05_MoreInfoProvided"], "isController": false}, {"data": [0.6156118143459915, 500, 1500, "S03_T01_Update KYC Verification details"], "isController": false}, {"data": [0.015191545574636724, 500, 1500, "S08_T05b_PayPartial_Acknowledge"], "isController": false}, {"data": [0.6, 500, 1500, "S09_T01_GetUserToken"], "isController": false}, {"data": [0.10700132100396301, 500, 1500, "S08_T05a_PayPartial"], "isController": false}, {"data": [0.5152838427947598, 500, 1500, "S06_T02_BlockUser"], "isController": false}, {"data": [0.5283842794759825, 500, 1500, "S06_T03_UnBlockUser"], "isController": false}, {"data": [0.6246006389776357, 500, 1500, "S07_T01_GetUserToken"], "isController": false}, {"data": [0.8418107833163785, 500, 1500, "S12_T02_Get user details"], "isController": false}, {"data": [0.6353833865814696, 500, 1500, "S07_T02_GetUserToken"], "isController": false}, {"data": [0.9455128205128205, 500, 1500, "S08_T03a_Request_To_Pay-1KB"], "isController": false}, {"data": [0.947452229299363, 500, 1500, "S09_T03c_Request_To_Pay-10KB"], "isController": false}, {"data": [0.9565916398713826, 500, 1500, "S08_T03b_Request_To_Pay-5KB"], "isController": false}, {"data": [0.05798575788402848, 500, 1500, "S12_T03_Get Threads_List"], "isController": false}, {"data": [0.01700251889168766, 500, 1500, "S08_T04b_AcknowledgeInFull"], "isController": false}, {"data": [0.9553846153846154, 500, 1500, "S09_T03d_Request_To_Pay-20KB"], "isController": false}, {"data": [0.946078431372549, 500, 1500, "S10_T03d_Request_To_Pay-20KB"], "isController": false}, {"data": [0.9575471698113207, 500, 1500, "S11_T03c_Request_To_Pay-10KB"], "isController": false}, {"data": [0.5551012822895373, 500, 1500, "S02_T01_Register new End User"], "isController": false}, {"data": [0.9294003868471954, 500, 1500, "S10_T03b_Request_To_Pay-5KB"], "isController": false}, {"data": [0.9893184130213631, 500, 1500, "S12_T05_Get_Msg_Identified_By_ThreadID_And_MsgID"], "isController": false}, {"data": [0.9553264604810997, 500, 1500, "S08_T03c_Request_To_Pay-10KB"], "isController": false}, {"data": [0.6, 500, 1500, "S10_T02_GetUserToken"], "isController": false}, {"data": [0.6069868995633187, 500, 1500, "S06_T01_GetUserToken"], "isController": false}, {"data": [0.019404915912031046, 500, 1500, "S09_T05a_RequestForExtension_Granted"], "isController": false}, {"data": [0.4676517571884984, 500, 1500, "S07_T04_MoreInfoRequested"], "isController": false}, {"data": [0.9590747330960854, 500, 1500, "S11_T03a_Request_To_Pay-1KB"], "isController": false}, {"data": [0.9283276450511946, 500, 1500, "S11_T03e_Request_To_Pay-40KB"], "isController": false}, {"data": [0.9997872159332709, 500, 1500, "BSF Sampler"], "isController": false}, {"data": [0.5, 500, 1500, "S05_T01_GetUserToken"], "isController": false}, {"data": [0.55, 500, 1500, "S09_T02_GetUserToken"], "isController": false}, {"data": [0.05670926517571885, 500, 1500, "S07_T03_SendPAMRequest"], "isController": false}, {"data": [1.0, 500, 1500, "Condition"], "isController": false}, {"data": [0.012195121951219513, 500, 1500, "S09_T05b_RequestForExtension_Declined"], "isController": false}, {"data": [0.9366883116883117, 500, 1500, "S08_T03e_Request_To_Pay-40KB"], "isController": false}, {"data": [0.6, 500, 1500, "S08_T02_GetUserToken"], "isController": false}, {"data": [0.1183641368462446, 500, 1500, "S10_T04_Decline"], "isController": false}, {"data": [0.75, 500, 1500, "S08_T03f_Request_To_Pay-200KB"], "isController": false}, {"data": [0.9541139240506329, 500, 1500, "S09_T03b_Request_To_Pay-5KB"], "isController": false}, {"data": [0.9229390681003584, 500, 1500, "S09_T03e_Request_To_Pay-40KB"], "isController": false}, {"data": [0.0, 500, 1500, "S12_T06_GetAllMessagesInAThread"], "isController": false}, {"data": [0.949685534591195, 500, 1500, "S09_T03a_Request_To_Pay-1KB"], "isController": false}, {"data": [0.905, 500, 1500, "S10_T03e_Request_To_Pay-40KB"], "isController": false}, {"data": [0.011927788523533205, 500, 1500, "S11_T05_NoteToPayer"], "isController": false}, {"data": [0.6484126984126984, 500, 1500, "S07_T06a_PAMRequest_Accept"], "isController": false}, {"data": [0.6958290946083419, 500, 1500, "S12_T01_Get user Token"], "isController": false}, {"data": [0.6, 500, 1500, "S08_T01_GetUserToken"], "isController": false}, {"data": [0.9851823708206687, 500, 1500, "S01_T01_CheckPIDavailability"], "isController": false}, {"data": [0.1130798969072165, 500, 1500, "S09_T04_RequestForExtension"], "isController": false}, {"data": [0.65, 500, 1500, "S11_T01_GetUserToken"], "isController": false}, {"data": [0.6, 500, 1500, "S11_T02_GetUserToken"], "isController": false}, {"data": [0.5689234522720341, 500, 1500, "S04_T01_UpdatePIDStatus"], "isController": false}, {"data": [0.9153102746693794, 500, 1500, "S12_T07_DownloadAttachment"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 90148, 1, 0.001109286950348316, 795.6226760438439, 1, 51117, 2553.0, 3585.0, 6194.970000000005, 20.28178697869139, 8.842776803459838, 59.95181636403049], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["S05_T02_Get user Blocked", 1414, 0, 0.0, 97.09193776520517, 33, 33560, 66.0, 75.0, 237.29999999999654, 0.32002418966435026, 0.08875670885222214, 0.3522141228044168], "isController": false}, {"data": ["S07_T06b_PAMRequest_Denied", 622, 0, 0.0, 921.228295819936, 117, 38422, 2011.5000000000011, 2323.9000000000005, 3165.5999999999967, 0.1406270383290071, 0.06651174412401678, 0.17990373067480406], "isController": false}, {"data": ["S08_T03d_Request_To_Pay-20KB", 329, 0, 0.0, 270.1641337386018, 86, 2330, 553.0, 1345.5, 1795.6, 0.07797801351840115, 0.030764763145931705, 2.3819084812910836], "isController": false}, {"data": ["S10_T03a_Request_To_Pay-1KB", 518, 0, 0.0, 274.8667953667952, 71, 32276, 272.0, 1187.3499999999942, 2195.5799999999936, 0.12010920198796961, 0.047621421881948886, 0.6731510841884351], "isController": false}, {"data": ["S10_T01_GetUserToken", 10, 0, 0.0, 883.5, 426, 1339, 1331.4, 1339.0, 1339.0, 0.0037982332897675978, 0.005115003619716325, 0.0014985217276036226], "isController": false}, {"data": ["S11_T03d_Request_To_Pay-20KB", 337, 0, 0.0, 312.14540059347183, 83, 26628, 429.0, 1283.9999999999995, 2016.8200000000015, 0.07693275278401826, 0.030502634404600992, 2.3505059605476517], "isController": false}, {"data": ["S11_T04_NoteToBiller", 1551, 0, 0.0, 2682.243713733073, 1065, 51117, 4482.2, 5487.999999999996, 7825.4400000000005, 0.35080783059170945, 0.1390898234572598, 0.9044264382442508], "isController": false}, {"data": ["S08_T04a_PayAll", 794, 0, 0.0, 2704.430730478586, 1071, 37744, 4597.0, 5733.25, 7796.449999999983, 0.18003351253545685, 0.07102884674250447, 0.5172447205852676], "isController": false}, {"data": ["S12_T04_Get_ListOfMessages_In_A_Thread", 1966, 0, 0.0, 1634.515768056971, 707, 44220, 2732.6, 3302.5499999999993, 4633.66, 0.44445569775927407, 0.2588509185436593, 0.5367708424232738], "isController": false}, {"data": ["S10_T03c_Request_To_Pay-10KB", 498, 0, 0.0, 359.6345381526108, 79, 40789, 448.2000000000003, 1247.2499999999989, 3110.4199999999996, 0.11271336606245815, 0.044689088497419927, 1.9797486347650117], "isController": false}, {"data": ["S11_T03b_Request_To_Pay-5KB", 322, 0, 0.0, 242.60559006211184, 73, 3246, 422.2999999999998, 1256.099999999999, 2173.1399999999985, 0.07332822464853121, 0.029073495319632492, 0.8227942394644762], "isController": false}, {"data": ["S07_T05_MoreInfoProvided", 1252, 0, 0.0, 926.4057507987217, 58, 35410, 1929.4, 2143.4499999999994, 3058.680000000001, 0.28303494848628297, 0.1632951163387802, 0.3957766613495884], "isController": false}, {"data": ["S03_T01_Update KYC Verification details", 1185, 0, 0.0, 712.2531645569627, 228, 34957, 982.4000000000001, 1115.7, 1549.5600000000004, 0.2678970488596742, 0.3198981391413187, 0.649180093028098], "isController": false}, {"data": ["S08_T05b_PayPartial_Acknowledge", 757, 1, 0.13210039630118892, 3127.282694848086, 1352, 41971, 5099.8, 6203.700000000002, 9203.579999999978, 0.17177506497726533, 0.0677524601332085, 0.4544322763900505], "isController": false}, {"data": ["S09_T01_GetUserToken", 10, 0, 0.0, 783.9, 456, 1232, 1206.5, 1232.0, 1232.0, 0.0037917423435242727, 0.005106262394257786, 0.0014959608464685608], "isController": false}, {"data": ["S08_T05a_PayPartial", 757, 0, 0.0, 2601.570673712024, 1095, 22995, 4352.2, 5174.500000000002, 7428.7199999999975, 0.172057733210961, 0.06788215255588695, 0.47299074120005385], "isController": false}, {"data": ["S06_T02_BlockUser", 458, 0, 0.0, 1034.9606986899564, 272, 36984, 1331.9, 1497.1, 2698.3799999999483, 0.10353443503315927, 0.02790576569253121, 0.129316935944737], "isController": false}, {"data": ["S06_T03_UnBlockUser", 458, 0, 0.0, 931.786026200874, 272, 4196, 1277.2000000000003, 1470.05, 1980.219999999989, 0.1035225701806175, 0.02790256774399456, 0.12940321272577188], "isController": false}, {"data": ["S07_T01_GetUserToken", 1252, 0, 0.0, 641.8178913738024, 241, 3926, 866.1000000000001, 932.0, 1110.6400000000003, 0.283004431098932, 0.381116318833425, 0.12526958319460013], "isController": false}, {"data": ["S12_T02_Get user details", 1966, 0, 0.0, 350.89674465920615, 30, 36364, 756.3, 909.5999999999995, 1303.2999999999993, 0.44465895834002434, 0.5309149119582047, 0.5180450559566885], "isController": false}, {"data": ["S07_T02_GetUserToken", 1252, 0, 0.0, 638.3458466453664, 244, 3885, 855.1000000000001, 918.0, 1126.7600000000002, 0.28305248136646527, 0.38118102715269103, 0.1258436891278909], "isController": false}, {"data": ["S08_T03a_Request_To_Pay-1KB", 312, 0, 0.0, 224.56089743589737, 70, 3165, 251.09999999999974, 1232.7999999999997, 2499.650000000002, 0.07128407755890419, 0.028123796224411413, 0.39888453555910247], "isController": false}, {"data": ["S09_T03c_Request_To_Pay-10KB", 314, 0, 0.0, 228.43949044585983, 82, 2500, 286.5, 1261.75, 1881.9000000000017, 0.07106500184452155, 0.028176162840698973, 1.2482178937261372], "isController": false}, {"data": ["S08_T03b_Request_To_Pay-5KB", 311, 0, 0.0, 286.35048231511286, 72, 26758, 202.40000000000003, 1203.3999999999999, 2316.76, 0.07112936739461817, 0.028062758229907957, 0.7977742036398339], "isController": false}, {"data": ["S12_T03_Get Threads_List", 1966, 0, 0.0, 2871.4404883011184, 1129, 42309, 4806.799999999999, 5819.299999999999, 8042.359999999993, 0.4444879537208005, 0.2922105400788638, 0.4900653317878748], "isController": false}, {"data": ["S08_T04b_AcknowledgeInFull", 794, 0, 0.0, 3083.788413098237, 1341, 18246, 5016.0, 6280.5, 8641.949999999997, 0.1798891619951747, 0.07097189594340877, 0.46114165062239615], "isController": false}, {"data": ["S09_T03d_Request_To_Pay-20KB", 325, 0, 0.0, 226.05846153846161, 83, 3139, 273.4000000000007, 1078.3999999999987, 2069.1600000000008, 0.07375503207890018, 0.029242717796907687, 2.253129798332183], "isController": false}, {"data": ["S10_T03d_Request_To_Pay-20KB", 510, 0, 0.0, 316.3607843137254, 84, 37833, 426.7000000000001, 1259.1999999999996, 2184.89, 0.11619543342833259, 0.04606967380068656, 3.5496343247120117], "isController": false}, {"data": ["S11_T03c_Request_To_Pay-10KB", 318, 0, 0.0, 214.41194968553447, 81, 2329, 288.50000000000034, 1055.6000000000004, 1905.77, 0.07439200328073413, 0.02949526692575982, 1.3069454482621161], "isController": false}, {"data": ["S02_T01_Register new End User", 5381, 0, 0.0, 757.8018955584477, 161, 39673, 924.0, 983.0, 1156.1800000000003, 1.2163211720806257, 0.8877515214045175, 6.607562943377435], "isController": false}, {"data": ["S10_T03b_Request_To_Pay-5KB", 517, 0, 0.0, 250.7350096711798, 71, 3244, 483.3999999999995, 1373.2999999999981, 2017.9200000000028, 0.11806062698642143, 0.046809193902819436, 1.3242620718418325], "isController": false}, {"data": ["S12_T05_Get_Msg_Identified_By_ThreadID_And_MsgID", 1966, 0, 0.0, 111.63936927772119, 39, 15666, 87.0, 101.0, 1769.4199999999946, 0.44452966229312185, 0.7722446036054837, 0.5490152776264106], "isController": false}, {"data": ["S08_T03c_Request_To_Pay-10KB", 291, 0, 0.0, 333.57388316151196, 80, 35762, 276.2000000000001, 1171.0, 1975.99999999998, 0.06668732216714089, 0.026310232573754803, 1.1711309712223579], "isController": false}, {"data": ["S10_T02_GetUserToken", 10, 0, 0.0, 718.3000000000001, 301, 1310, 1281.2, 1310.0, 1310.0, 0.003799178465648588, 0.0051162764688763695, 0.0014951844938050594], "isController": false}, {"data": ["S06_T01_GetUserToken", 458, 0, 0.0, 676.3275109170299, 247, 3578, 918.1, 999.1999999999998, 1271.2199999999987, 0.10353073721344534, 0.1394227408372472, 0.04104831963736212], "isController": false}, {"data": ["S09_T05a_RequestForExtension_Granted", 773, 0, 0.0, 3111.598965071152, 1360, 41802, 5137.200000000001, 6147.699999999999, 8362.82, 0.17576035110233346, 0.06968623295658924, 0.4536470780893236], "isController": false}, {"data": ["S07_T04_MoreInfoRequested", 1252, 0, 0.0, 1197.4105431309915, 75, 18575, 2020.2000000000003, 2262.0, 2860.3400000000006, 0.283019784936611, 0.13374303421227704, 0.381938119049266], "isController": false}, {"data": ["S11_T03a_Request_To_Pay-1KB", 281, 0, 0.0, 208.7081850533809, 72, 3065, 298.80000000000007, 986.1999999999996, 1927.0600000000004, 0.0636538967737668, 0.025237775478661448, 0.35662344315537126], "isController": false}, {"data": ["S11_T03e_Request_To_Pay-40KB", 293, 0, 0.0, 266.70307167235484, 99, 2244, 508.4000000000001, 1202.4000000000003, 1816.8000000000002, 0.06652840263261744, 0.026377472137541682, 3.760024193320412], "isController": false}, {"data": ["BSF Sampler", 23498, 0, 0.0, 2.6315431100519193, 1, 758, 3.0, 4.0, 8.0, 5.286655615491084, 0.08811080974609295, 0.0], "isController": false}, {"data": ["S05_T01_GetUserToken", 2, 0, 0.0, 857.0, 555, 1159, 1159.0, 1159.0, 1159.0, 7.611667925763404E-4, 0.0010250478583620833, 3.010474130795096E-4], "isController": false}, {"data": ["S09_T02_GetUserToken", 10, 0, 0.0, 824.8000000000001, 256, 1531, 1504.2, 1531.0, 1531.0, 0.0037924426478379474, 0.00510720547985208, 0.001492533581131536], "isController": false}, {"data": ["S07_T03_SendPAMRequest", 1252, 0, 0.0, 2132.3075079872183, 129, 37022, 2779.8, 3007.35, 3485.8100000000004, 0.28298025218241735, 0.15375935493272777, 0.5051441005454602], "isController": false}, {"data": ["Condition", 12287, 0, 0.0, 2.071783185480595, 1, 80, 2.0, 3.0, 5.0, 2.769538012117715, 0.019401906889020125, 0.0], "isController": false}, {"data": ["S09_T05b_RequestForExtension_Declined", 779, 0, 0.0, 3095.634146341463, 1233, 19516, 5193.0, 6208.0, 8831.800000000005, 0.17623198372964793, 0.06987322792405962, 0.4586506217182731], "isController": false}, {"data": ["S08_T03e_Request_To_Pay-40KB", 308, 0, 0.0, 263.62662337662334, 97, 3210, 445.1, 1401.4000000000003, 1949.0500000000013, 0.07040242988958019, 0.027775958667373434, 3.97849356486361], "isController": false}, {"data": ["S08_T02_GetUserToken", 10, 0, 0.0, 767.0999999999999, 326, 1390, 1347.5000000000002, 1390.0, 1390.0, 0.0037827233944041417, 0.005094116758675109, 0.0014850144575688133], "isController": false}, {"data": ["S10_T04_Decline", 2543, 0, 0.0, 2646.513959889896, 1089, 46931, 4519.799999999999, 5484.799999999996, 7479.639999999999, 0.5747931829483296, 0.22789651589552914, 1.3561526660187153], "isController": false}, {"data": ["S08_T03f_Request_To_Pay-200KB", 10, 0, 0.0, 653.4, 179, 1882, 1817.7000000000003, 1882.0, 1882.0, 0.003782988129361549, 0.0014925070354121735, 0.9995807266968877], "isController": false}, {"data": ["S09_T03b_Request_To_Pay-5KB", 316, 0, 0.0, 269.28164556962014, 70, 21843, 291.90000000000003, 835.0499999999998, 2423.3299999999977, 0.0726621861384463, 0.028809421457235546, 0.8150369824083928], "isController": false}, {"data": ["S09_T03e_Request_To_Pay-40KB", 279, 0, 0.0, 315.99283154121866, 95, 5116, 468.0, 1532.0, 3126.9999999999995, 0.06494759613582754, 0.025750707061666, 3.6704271370901758], "isController": false}, {"data": ["S12_T06_GetAllMessagesInAThread", 1966, 0, 0.0, 3675.5111902339804, 1787, 37470, 5749.3, 6780.149999999999, 8631.289999999999, 0.44435996230851105, 0.8413810419732565, 0.5344854959755588], "isController": false}, {"data": ["S09_T03a_Request_To_Pay-1KB", 318, 0, 0.0, 332.78616352201277, 74, 37606, 219.30000000000007, 1239.400000000001, 2397.2000000000003, 0.07275820640496439, 0.02884749199259331, 0.4073464817574814], "isController": false}, {"data": ["S10_T03e_Request_To_Pay-40KB", 500, 0, 0.0, 327.5440000000001, 101, 3851, 868.3000000000027, 1582.7999999999997, 2211.6500000000005, 0.11334699391303973, 0.04494031203974036, 6.40565482201915], "isController": false}, {"data": ["S11_T05_NoteToPayer", 1551, 0, 0.0, 3124.0651192778896, 1367, 45859, 5164.0, 6110.199999999995, 9576.08, 0.3507858530394995, 0.1390811097012078, 0.9043697773674596], "isController": false}, {"data": ["S07_T06a_PAMRequest_Accept", 630, 0, 0.0, 865.8809523809523, 99, 4287, 2056.9, 2276.0499999999993, 3064.6299999999983, 0.1444476391065157, 0.0682378062977795, 0.18507353760522322], "isController": false}, {"data": ["S12_T01_Get user Token", 1966, 0, 0.0, 582.1968463886067, 228, 3985, 783.0, 845.6499999999999, 1122.9399999999987, 0.44454031682202966, 0.5986534149390419, 0.1727127492003475], "isController": false}, {"data": ["S08_T01_GetUserToken", 10, 0, 0.0, 679.2, 410, 1228, 1200.3000000000002, 1228.0, 1228.0, 0.0037818521772312076, 0.005092943508204917, 0.0014883656517814226], "isController": false}, {"data": ["S01_T01_CheckPIDavailability", 1316, 0, 0.0, 340.72188449848005, 55, 12486, 431.29999999999995, 468.14999999999986, 541.1499999999996, 0.29745894117274774, 0.08080158834541853, 0.07586330514235534], "isController": false}, {"data": ["S09_T04_RequestForExtension", 1552, 0, 0.0, 2675.1578608247387, 1100, 41656, 4506.3, 5346.149999999992, 7892.560000000001, 0.3511248665182531, 0.139215523248448, 0.9319896359341913], "isController": false}, {"data": ["S11_T01_GetUserToken", 10, 0, 0.0, 775.0, 376, 1104, 1103.2, 1104.0, 1104.0, 0.0037999436088368447, 0.005117306871666024, 0.0014991965019239115], "isController": false}, {"data": ["S11_T02_GetUserToken", 10, 0, 0.0, 749.9, 315, 1122, 1115.4, 1122.0, 1122.0, 0.0038006122786380884, 0.005118207355705003, 0.0014957487776280757], "isController": false}, {"data": ["S04_T01_UpdatePIDStatus", 3279, 0, 0.0, 754.9231473010065, 241, 33209, 1041.0, 1197.0, 1669.7999999999993, 0.7410569746026962, 0.2582788687626292, 0.30748968348233946], "isController": false}, {"data": ["S12_T07_DownloadAttachment", 1966, 0, 0.0, 270.8575788402846, 34, 28912, 690.3, 839.2999999999997, 1262.33, 0.4445391106233089, 0.5747751781887315, 0.5759424007271358], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 1, 100.0, 0.001109286950348316], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 90148, 1, "400\/Bad Request", 1, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S08_T05b_PayPartial_Acknowledge", 757, 1, "400\/Bad Request", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
